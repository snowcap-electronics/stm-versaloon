void DelayUS(uint32);
void DelayMS(uint32);
void DelayUSMS(uint16 dly);
