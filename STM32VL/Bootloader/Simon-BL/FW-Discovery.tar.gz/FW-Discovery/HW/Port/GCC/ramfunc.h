#define RAMFUNC		
