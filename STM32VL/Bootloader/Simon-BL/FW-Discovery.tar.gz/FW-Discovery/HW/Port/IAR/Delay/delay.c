#include "stm32f10x_type.h"

void DelayUS(volatile uint32 dly)
{
	dly = (dly << 3);
	while(dly--);
}

void DelayMS(uint32 dly)
{
	DelayUS(1000 * dly);
}
