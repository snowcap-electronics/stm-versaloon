

void DelayUS(uint32);
void DelayMS(uint32);
