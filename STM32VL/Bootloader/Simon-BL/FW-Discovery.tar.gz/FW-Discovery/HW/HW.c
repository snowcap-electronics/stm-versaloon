#include "app_cfg.h"
#include "stm32f10x_lib.h"
#include "HW.h"
#include "bl.h"

#include "usb_lib.h"
#include "VCOM/usb_desc.h"
#include "VCOM/usb_istr.h"
#include "VCOM/usb_pwr.h"
#include "Delay/delay.h"

#define FWU_KEY				0x55AA
#define APP_ADDR			((void (*)(void))(*(u32 *)(BL_APP_START + 4))) // none return,add __no_return?

uint8 BL_run = 0;

void Sys_Fini(void)
{
  BKP_WriteBackupRegister(BKP_DR1, 0);
  PWR_BackupAccessCmd(DISABLE);

  if (BL_run)
  {
    // Reset USB, and Reset MCU
    USB_Disable();
    USB_D_CLR();
    USB_D_SETOUTPUT();
    DelayMS(10);
    USB_D_SET();
  }

  // deinit all
  KEY_Fini();
  LED_Fini();

  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB | RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOC | RCC_APB2Periph_AFIO, DISABLE);
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_BKP | RCC_APB1Periph_PWR | RCC_APB1Periph_USB, DISABLE);
  RCC_DeInit();
}

/*******************************************************************************
* Function Name  : Sys_Init
* Description    : Initialize the system
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void Sys_Init(void)
{
  /* Check Bootloader Condition */
  /* Enable GPIO */
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC | RCC_APB2Periph_GPIOB | RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO, ENABLE);
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_BKP | RCC_APB1Periph_PWR, ENABLE);

  PWR_BackupAccessCmd(ENABLE);

  KEY_Init();

  DelayMS(10);

  if(!KEY_IsDown() && (BKP_ReadBackupRegister(BKP_DR1) != FWU_KEY))
  {
    // Realease resources and jump to Application
    Sys_Fini();

    __MSR_MSP(*(vu32 *)BL_APP_START);
    APP_ADDR();
  }
  BL_run = 1;

  RCC_Configuration();

  GPIO_Configuration();

  USB_Init();
}

/*******************************************************************************
* Function Name  : RCC_Configuration
* Description    : Configures the different system clocks.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void RCC_Configuration(void)
{
  /* RCC system reset(for debug purpose) */
  RCC_DeInit();

  /* Enable HSE */
  RCC_HSEConfig(RCC_HSE_ON);

  /* Wait till HSE is ready */
  if(RCC_WaitForHSEStartUp() == SUCCESS)
  {
    /* Enable Prefetch Buffer */
    FLASH_PrefetchBufferCmd(FLASH_PrefetchBuffer_Enable);

    /* Flash 2 wait state */
    FLASH_SetLatency(FLASH_Latency_2);
 	
    /* HCLK = SYSCLK */
    RCC_HCLKConfig(RCC_SYSCLK_Div1); 
  
    /* PCLK2 = HCLK */
    RCC_PCLK2Config(RCC_HCLK_Div1); 

    /* PCLK1 = HCLK/2 */
    RCC_PCLK1Config(RCC_HCLK_Div2);

    /* PLLCLK = 72 MHz */
    RCC_PLLConfig(RCC_PLLSource_HSE_Div1, (_SYS_FREQUENCY * 1000000 / HSE_Value - 2) << 18);

    /* Enable PLL */ 
    RCC_PLLCmd(ENABLE);

    /* Wait till PLL is ready */
    while(RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET)
    {
    }

    /* Select PLL as system clock source */
    RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);

    /* Wait till PLL is used as system clock source */
    while((RCC_GetSYSCLKSource() >> 2) != RCC_SYSCLKSource_PLLCLK)
    {
    }
  }

#if _SYS_FREQUENCY == 72
  RCC_USBCLKConfig(RCC_USBCLKSource_PLLCLK_1Div5);
#elif _SYS_FREQUENCY == 48
  RCC_USBCLKConfig(RCC_USBCLKSource_PLLCLK_Div1);
#else
#	error _SYS_FREQUENCY not supported
#endif

  /* Enable USB clock */
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_USB, ENABLE);
}

/*******************************************************************************
* Function Name  : GPIO_Configuration
* Description    : Configures the different GPIO ports.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void GPIO_Configuration(void)
{
  // Disable JTAG
  //GPIO_PinRemapConfig(GPIO_Remap_SWJ_Disable, ENABLE);

  // LED
  LED_ALL_OFF();
  LED_Init();
}

void GPIO_Dir(GPIO_TypeDef* GPIOx, uint8 mode, uint8 pin)
{
	uint32 tmp_reg;

	if(pin < 8)
	{
		tmp_reg = GPIOx->CRL;
		tmp_reg &= ~(((u32)0x0F) << ((pin - 0) * 4));
		tmp_reg |= (u32)(mode & 0x0F) << ((pin - 0) * 4);
		GPIOx->CRL = tmp_reg;
	}
	else
	{
		tmp_reg = GPIOx->CRH;
		tmp_reg &= ~(((u32)0x0F) << ((pin - 8) * 4));
		tmp_reg |= (u32)(mode & 0x0F) << ((pin - 8) * 4);
		GPIOx->CRH = tmp_reg;
	}

	if(mode & 0x20)
	{
		if(mode & 0x10)
		{
			GPIOx->BSRR = (((u32)0x01) << pin);
		}
		else
		{
			GPIOx->BRR = (((u32)0x01) << pin);
		}
	}
}

extern vu32 count_in,count_out,buffer_ptr;
extern u8 buffer_out[VIRTUAL_COM_PORT_DATA_SIZE];
u8 USB_Out(u8 *data,u32 len)
{
  u32 sent_len = 0;

  while(sent_len < len)
  {
    if((len - sent_len) > VIRTUAL_COM_PORT_DATA_SIZE)
      count_in = VIRTUAL_COM_PORT_DATA_SIZE;
    else
      count_in = len - sent_len;

    UserToPMABufferCopy(data + sent_len, ENDP1_TXADDR, count_in);
    sent_len += count_in;

    SetEPTxCount(ENDP1, count_in);
    SetEPTxValid(ENDP1);

    while(count_in)USB_Istr();
  }

  if(!(len % VIRTUAL_COM_PORT_DATA_SIZE))
  {
    // Send ZLP
    SetEPTxCount(ENDP1,0);
    SetEPTxValid(ENDP1);
  }

  return 0;
}

u8 USB_In(u8 *data,u32 len)
{
  while(len)
  {
    while(!count_out)USB_Istr();
    *data++ = buffer_out[buffer_ptr++];
    count_out--;
    len--;
  }

  return 0;
}


/*******************************************************************************
* Function Name  : USB_Cable_Config
* Description    : Software Connection/Disconnection of USB Cable
* Input          : None.
* Return         : Status
*******************************************************************************/
void USB_Cable_Config (FunctionalState NewState)
{
}

/*******************************************************************************
* Function Name  : Enter_LowPowerMode
* Description    : Power-off system clocks and power while entering suspend mode
* Input          : None.
* Return         : None.
*******************************************************************************/
void Enter_LowPowerMode(void)
{
}

/*******************************************************************************
* Function Name  : Leave_LowPowerMode
* Description    : Restores system clocks and power while exiting suspend mode
* Input          : None.
* Return         : None.
*******************************************************************************/
void Leave_LowPowerMode(void)
{
}
