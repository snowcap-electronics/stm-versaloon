#include "app_cfg.h"
#include "stm32f10x_lib.h"
#include "bl.h"

#include "usb_lib.h"
#include "usb_pwr.h"

#include "delay.h"

extern void Sys_Fini(void);

u8 BL_Func_Get(void);
u8 BL_Func_GetVersionAndReadProtectionStatus(void);
u8 BL_Func_GetID(void);
u8 BL_Func_ReadMemory(void);
u8 BL_Func_Go(void);
u8 BL_Func_WriteMemory(void);
u8 BL_Func_Erase(void);
u8 BL_Func_WriteProtect(void);
u8 BL_Func_WriteUnprotect(void);
u8 BL_Func_ReadoutProtect(void);
u8 BL_Func_ReadoutUnprotect(void);

const BL_CMD commands[] = {
{BL_CMD_GET,BL_Func_Get},
{BL_CMD_GETVERSIONANDREADPROTECTIONSTATUS,BL_Func_GetVersionAndReadProtectionStatus},
{BL_CMD_GETID,BL_Func_GetID},
{BL_CMD_READMEMORY,BL_Func_ReadMemory},
{BL_CMD_GO,BL_Func_Go},
{BL_CMD_WRITEMEMORY,BL_Func_WriteMemory},
{BL_CMD_ERASE,BL_Func_Erase},
{BL_CMD_WRITEPROTECT,BL_Func_WriteProtect},
{BL_CMD_WRITEUNPROTECT,BL_Func_WriteUnprotect},
{BL_CMD_READOUTPROTECT,BL_Func_ReadoutProtect},
{BL_CMD_READOUTUNPROTECT,BL_Func_ReadoutUnprotect},
};

// max package 256 bytes data plus 1 byte checksum plus 1 byte data length
u8 BL_Buffer[258];
u32 BL_Address;
u32 BL_DataSize;

#define dimof(a)	(sizeof(a) / sizeof(*(a)))

void BL_SendNACK(void)
{
  BL_Buffer[0] = BL_CHAR_NACK;
  BL_Out(BL_Buffer,1);
}

void BL_SendACK(void)
{
  BL_Buffer[0] = BL_CHAR_ACK;
  BL_Out(BL_Buffer,1);
}

// return 1 on checksum error
u32 BL_ReadDataVerifyCheck(u32 *buf,u32 start_idx,u32 len)
{
  u32 i;
  u8 chksum;

  if(len > 1)
    chksum = 0x00;
  else
    chksum = 0xFF;

  BL_In(BL_Buffer + start_idx,len + 1 - start_idx);

  if(buf)
    *buf = 0;
  for(i = 0;i < len;i++)
  {
    if(buf)
    {
      *buf <<= 8;
      *buf += BL_Buffer[i];
    }
    chksum ^= BL_Buffer[i];
  }
  chksum ^= BL_Buffer[len];
  if(chksum)
    return 1;
  else
    return 0;
}

u8 BL_ExecuteCmd(u8 cmd)
{
  u8 i;

  for(i = 0;i < dimof(commands);i++)
    if((commands[i].cmd == cmd) && (commands[i].func != 0))
      return commands[i].func();

  BL_SendNACK();

  return 1;
}

u8 BL_Func_Get(void)
{
  u8 i;

  BL_Buffer[0] = BL_CHAR_ACK;
  BL_Buffer[1] = dimof(commands);
  BL_Buffer[2] = BL_VERSION;
  for(i = 0;i < dimof(commands);i++)
    BL_Buffer[3 + i] = commands[i].cmd;
  BL_Buffer[3 + i] = BL_CHAR_ACK;

  BL_Out(BL_Buffer,4 + i);

  return 0;
}

u8 BL_Func_GetVersionAndReadProtectionStatus(void)
{
  BL_Buffer[0] = BL_CHAR_ACK;
  BL_Buffer[1] = BL_VERSION;
  BL_Buffer[2] = 0;
  BL_Buffer[3] = 0;
  BL_Buffer[4] = BL_CHAR_ACK;
  BL_Out(BL_Buffer,5);

  return 0;
}

u8 BL_Func_GetID(void)
{
  BL_Buffer[0] = BL_CHAR_ACK;
  BL_Buffer[1] = 3;
  BL_Buffer[2] = 0x06;
  BL_Buffer[3] = 0x41;
  BL_Buffer[4] = 0x00;
  BL_Buffer[5] = 0x41;
  BL_Buffer[6] = BL_CHAR_ACK;
  BL_Out(BL_Buffer,7);

  return 0;
}

u8 BL_Func_ReadMemory(void)
{
  u32 i;

  // check ROP
//  if(FLASH_GetReadOutProtectionStatus() == SET)
//    goto NACK_And_Return;
  BL_SendACK();

  // Receive the start address(4 bytes) with checksum
  if(BL_ReadDataVerifyCheck(&BL_Address,0,4) || 
    ((BL_Address != 0x1FFFF7E0)))
    goto NACK_And_Return;
  BL_SendACK();

  // Receive the number of bytes to be read(1 byte) and a checksum(1 byte)
  if(BL_ReadDataVerifyCheck(&BL_DataSize,0,1))
    goto NACK_And_Return;
  BL_SendACK();

  // Send data to the host
  for(i = 0;i <= BL_DataSize;i++)
    BL_Buffer[i] = *(u8 *)(BL_Address + i);
  BL_Out(BL_Buffer,BL_DataSize + 1);
  return 0;

NACK_And_Return:
  BL_SendNACK();
  return 1;
}

u8 BL_Func_Go(void)
{
  // check ROP
//  if(FLASH_GetReadOutProtectionStatus() == SET)
//    goto NACK_And_Return;
  BL_SendACK();

  // Receive the start address(4 bytes) and checksum
  if(BL_ReadDataVerifyCheck(&BL_Address,0,4))
    goto NACK_And_Return;
  // Check address valid
  if( (((BL_Address >= BL_FLASH_START) && (BL_Address < BL_FLASH_END)) ||
       ((BL_Address >= BL_RAM_START) && (BL_Address < BL_RAM_END))) &&
	  (BL_Address != 0x08002000))
    goto NACK_And_Return;

  BL_SendACK();

  Sys_Fini();

  // jump to address
  __MSR_MSP(*(vu32 *)BL_Address);
  ((void (*)(void))(*(u32 *)(BL_Address + 4)))();

  return 0;

NACK_And_Return:
  BL_SendNACK();
  return 1;
}

u8 BL_Func_WriteMemory(void)
{
  u32 i,data;

  // check ROP
//  if(FLASH_GetReadOutProtectionStatus() == SET)
//    goto NACK_And_Return;
  BL_SendACK();

  // Receive the start address(4 bytes) and checksum
  if(BL_ReadDataVerifyCheck(&BL_Address,0,4))
    goto NACK_And_Return;
  BL_SendACK();

  BL_In(BL_Buffer,1);
  BL_DataSize = BL_Buffer[0] + 1;
  if(BL_ReadDataVerifyCheck((u32*)0,1,BL_DataSize + 1))
    goto NACK_And_Return;

  // Do Write
  if((BL_Address >= BL_APP_START) && (BL_Address < BL_APP_END) && ((BL_Address & 0x03) == 0))
  {
    // Write Flash
    while(BL_DataSize & 0x03)
    {
      BL_Buffer[BL_DataSize + 1] = 0xFF;
      BL_DataSize++;
    }
    for(i = 0;i < (BL_DataSize >> 2);i++)
    {
      data = BL_Buffer[i * 4 + 1];
      data += BL_Buffer[i * 4 + 2] << 8;
      data += BL_Buffer[i * 4 + 3] << 16;
      data += BL_Buffer[i * 4 + 4] << 24;
      if(FLASH_ProgramWord(BL_Address + i * 4,data) != FLASH_COMPLETE)
        goto NACK_And_Return;
    }
  }
  else if((BL_Address >= BL_RAM_START) && (BL_Address < BL_RAM_END))
  {
    // Write Ram, not supported
    goto NACK_And_Return;
  }
  else if(BL_Address == 0x1FFFF800)
  {
    // Write SIF?
    goto NACK_And_Return;
  }

  goto ACK_And_Return;

ACK_And_Return:
  BL_SendACK();
  return 0;

NACK_And_Return:
  BL_SendNACK();
  return 1;
}

u8 BL_Func_Erase(void)
{
  u32 i;

  // check ROP
//  if(FLASH_GetReadOutProtectionStatus() == SET)
//    goto NACK_And_Return;
  BL_SendACK();

  BL_In(BL_Buffer,1);
  BL_DataSize = BL_Buffer[0];
  if(BL_DataSize == 0xFF)
  {
    // Global Erase, but only erase application flash
    BL_In(BL_Buffer,1);
    if(BL_Buffer[0] == 0x00)
    {
      // Start Erase Global, Erase APP Flash Pages Only
      for(i = 0;i <= BL_APP_PAGE_NUM;i++)
        if(FLASH_ErasePage(BL_GetAddrByPage(BL_APP_START_PAGE + i)) != FLASH_COMPLETE)
          goto NACK_And_Return;

      goto ACK_And_Return;
    }
  }
  else
  {
    BL_DataSize += 1;
    if(BL_ReadDataVerifyCheck((u32*)0,1,BL_DataSize + 1))
      goto NACK_And_Return;

    // Erasing the corresponding sectors, fail if attemp to erase bootloader flash
    for(i = 1;i <= BL_DataSize;i++)
    {
      if(BL_Buffer[i] < BL_APP_START_PAGE)
        continue;
      if(FLASH_ErasePage(BL_GetAddrByPage(BL_Buffer[i])) != FLASH_COMPLETE)
        goto NACK_And_Return;
    }

    goto ACK_And_Return;
  }

ACK_And_Return:
  BL_SendACK();
  return 0;

NACK_And_Return:
  BL_SendNACK();
  return 1;
}

u8 BL_Func_WriteProtect(void)
{
/*
  u32 i;

  // check ROP
  if(FLASH_GetReadOutProtectionStatus() == SET)
    goto NACK_And_Return;
  BL_SendACK();

  BL_In(BL_Buffer,1);
  BL_DataSize = BL_Buffer[0] + 1;
  if(BL_ReadDataVerifyCheck((u32*)0,1,BL_DataSize + 1))
    goto NACK_And_Return;

  // Write-protect the requested sectors
  for(i = 1;i <= BL_DataSize;i++)
    if(FLASH_EnableWriteProtection(i) != FLASH_COMPLETE)
      goto NACK_And_Return;

  BL_SendACK();

  // Generate system reset
  NVIC_GenerateSystemReset();

  return 0;

NACK_And_Return:
*/
  BL_SendNACK();
  return 1;
}

u8 BL_Func_WriteUnprotect(void)
{
/*
  // check ROP
  if(FLASH_GetReadOutProtectionStatus() == SET)
    goto NACK_And_Return;
  BL_SendACK();

  // Remove the protection for the entire Flash memory
  if(FLASH_EraseOptionBytes() != FLASH_COMPLETE)
    goto NACK_And_Return;
  goto ACK_And_Return;

ACK_And_Return:
  BL_SendACK();
  return 0;

NACK_And_Return:
*/
  BL_SendNACK();
  return 1;
}

u8 BL_Func_ReadoutProtect(void)
{
/*
  // check ROP
  if(FLASH_GetReadOutProtectionStatus() == SET)
    goto NACK_And_Return;
  BL_SendACK();

  // Activate Read protection for Flash memory
  if(FLASH_ReadOutProtection(ENABLE) != FLASH_COMPLETE)
    goto NACK_And_Return;
  BL_SendACK();
  // Generate system reset
//  NVIC_GenerateSystemReset();
  return 0;

NACK_And_Return:
*/
  BL_SendNACK();
  return 1;
}

u8 BL_Func_ReadoutUnprotect(void)
{
/*
  u32 i;

  BL_SendACK();

  // Erase Flash memory
  for(i = 0;i <= BL_APP_PAGE_NUM;i++)
    if(FLASH_ErasePage(BL_GetAddrByPage(BL_APP_START_PAGE + i)) != FLASH_COMPLETE)
      goto NACK_And_Return;

  // Disable ROP
  if(FLASH_ReadOutProtection(DISABLE) != FLASH_COMPLETE)
    goto NACK_And_Return;

  BL_SendACK();
  // Generate system reset
//  NVIC_GenerateSystemReset();
  return 0;

NACK_And_Return:
*/
  BL_SendNACK();
  return 1;
}
