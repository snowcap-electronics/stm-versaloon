#ifndef __BL_H__
#define __BL_H__

#define BL_VERSION					0x20

#define BL_CMD_GET					0x00
#define BL_CMD_GETVERSIONANDREADPROTECTIONSTATUS	0x01
#define BL_CMD_GETID				0x02
#define BL_CMD_READMEMORY			0x11
#define BL_CMD_GO					0x21
#define BL_CMD_WRITEMEMORY			0x31
#define BL_CMD_ERASE				0x43
#define BL_CMD_WRITEPROTECT			0x63
#define BL_CMD_WRITEUNPROTECT		0x73
#define BL_CMD_READOUTPROTECT		0x82
#define BL_CMD_READOUTUNPROTECT		0x92

#define BL_CHAR_SYNC				0x7F
#define BL_CHAR_ACK					0x79
#define BL_CHAR_NACK				0x1F

#define BL_FLASH_PAGE_SIZE			(1 * 1024)
#define BL_FLASH_START				0x08000000
#define BL_FLASH_SIZE				(64 * 1024)
#define BL_FLASH_END				(BL_FLASH_START + BL_FLASH_SIZE)
#define BL_RAM_START				0x20000000
#define BL_RAM_SIZE				(20 * 1024)
#define BL_RAM_END				(BL_RAM_START + BL_RAM_SIZE)

// size of Bootloader
#define BL_BL_START				BL_FLASH_START
#define BL_BL_START_PAGE			0
#define BL_BL_SIZE				(8 * 1024)
//#define BL_BL_SIZE				(20 * 1024)
#define BL_BL_PAGE_NUM				(BL_BL_SIZE / BL_FLASH_PAGE_SIZE))
#define BL_APP_START				(BL_BL_START + BL_BL_SIZE)
#define BL_APP_START_PAGE			(BL_BL_SIZE / BL_FLASH_PAGE_SIZE)
#define BL_APP_SIZE				(BL_FLASH_SIZE - BL_BL_SIZE)
#define BL_APP_END				(BL_APP_START + BL_APP_SIZE)
#define BL_APP_PAGE_NUM				(BL_APP_SIZE / BL_FLASH_PAGE_SIZE)

#define BL_GetAddrByPage(p)			(BL_FLASH_START + (p) * BL_FLASH_PAGE_SIZE)

typedef struct _BL_CMD
{
  u8 cmd;
  u8 (*func)(void);
}
BL_CMD;

u8 BL_ExecuteCmd(u8 cmd);
void BL_SendACK(void);
void BL_SendNACK(void);

extern u8 USB_Out(u8 *data,u32 len);
extern u8 USB_In(u8 *data,u32 len);

#define BL_Out(dat,len)					USB_Out(dat,len)
#define BL_In(dat,len)					USB_In(dat,len)

#endif /* #ifndef __BL_H__ */
