/******************** (C) COPYRIGHT 2007 STMicroelectronics ********************
* File Name          : main.c
* Author             : MCD Application Team
* Version            : V1.0
* Date               : 10/08/2007
* Description        : Main program body
********************************************************************************
* THE PRESENT SOFTWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
* AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
* CONTENT OF SUCH SOFTWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
* INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "app_cfg.h"

#include "stm32f10x_lib.h"
#include "usb_lib.h"
#include "VCOM/usb_desc.h"
#include "VCOM/usb_istr.h"
#include "VCOM/usb_pwr.h"

#include "BL/bl.h"
#include "Delay/delay.h"

/* Private typedef -----------------------------------------------------------*/

/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
void Sys_Init(void);
void RCC_Configuration(void);
void NVIC_Configuration(void);
void GPIO_Configuration(void);

u8 USB_Out(u8 *data,u32 len);
u8 USB_In(u8 *data,u32 len);

/* Private functions ---------------------------------------------------------*/

static void Validate(void)
{
  uint32 chk_val;
  uint32 i;

  chk_val = 0;
  if(*(uint32*)0x08001FFC == 0xFFFFFFFF)
  {
    chk_val += *(uint32*)0x1FFFF7E8;
    chk_val += *(uint32*)0x1FFFF7EC;
    chk_val += *(uint32*)0x1FFFF7F0;

    for(i = 0x08000000; i < 0x08000400; i += 4)
    {
      chk_val += *(uint32*)i;
    }

    FLASH_ProgramWord(0x08001FFC, chk_val);
  }
}

/*******************************************************************************
* Function Name  : main
* Description    : Main program.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
int main(void)
{
  u8 ch1,ch2;

  // add read-protection
  if(RESET == FLASH_GetReadOutProtectionStatus())
  {
    FLASH_Unlock();
    FLASH_ReadOutProtection(ENABLE);
  }

  Sys_Init();

  DelayMS(10);

  /* Unlock the Flash Program Erase controller */
  FLASH_Unlock();
  /* Clear All pending flags */
  FLASH_ClearFlag(FLASH_FLAG_BSY | FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPRTERR);

  Validate();

  LED_RED_ON();

  while(1)
  {
    USB_In(&ch1,1);
    if(ch1 == BL_CHAR_SYNC)
        BL_SendACK();
    else
    {
      USB_In(&ch2,1);

      if((ch1 ^ ch2) == 0xFF)
        BL_ExecuteCmd(ch1);
//      else
//        NVIC_GenerateSystemReset();
    }
  }
}

/******************* (C) COPYRIGHT 2007 STMicroelectronics *****END OF FILE****/
