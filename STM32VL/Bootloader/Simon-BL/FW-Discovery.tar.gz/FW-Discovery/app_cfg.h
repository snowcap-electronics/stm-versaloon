
#ifndef HSE_Value
/* In the following line adjust the value of External High Speed oscillator (HSE)
   used in your application */
//#define HSE_Value    ((u32)12000000) /* Value of the External oscillator in Hz*/
#define HSE_Value    ((u32)8000000) /* Value of the External oscillator in Hz*/
#endif

#define _SYS_FREQUENCY				72



/****************************** GPIO ******************************/
#define GPIO_SetPins(port, msk)		(port)->BSRR = (msk)
#define GPIO_ClrPins(port, msk)		(port)->BRR = (msk)
#define GPIO_GetOutPins(port, msk)	((port)->ODR & (msk))
#define GPIO_GetInPins(port, msk)	((port)->IDR & (msk))

/****************************** LED ******************************/

/*  STM32VL Discovery  Definitions Begin
#define	STM32VL_ST_LINK_LED	GPIO_PIN_8	//GPIOA

#define STM32VL_T_JRST		GPIO_PIN_1	//GPIOB
#define STM32VL_T_NRST		GPIO_PIN_0	//GPIOB
#define	STM32VL_T_JTDI		GPIO_PIN_7	//GPIOA
#define STM32VL_T_JTDO		GPIO_PIN_6	//GPIOA


****************************** LED ******************************
#define LED_RED_PORT					GPIOA
#define LED_RED_PIN					STM32VL_T_JTDI
#define LED_GREEN_PORT					GPIOA
#define LED_GREEN_PIN					STM32VL_T_JTDO
#define LED_RED_ON()					GPIO_ClrPins(LED_RED_PORT, LED_RED_PIN)
#define LED_RED_OFF()					GPIO_SetPins(LED_RED_PORT, LED_RED_PIN)
#define LED_GREEN_ON()					GPIO_ClrPins(LED_GREEN_PORT, LED_GREEN_PIN)
#define LED_GREEN_OFF()					GPIO_SetPins(LED_GREEN_PORT, LED_GREEN_PIN)

#define LED_Init()						do{\
											GPIO_SetMode(LED_RED_PORT, LED_RED_PIN, GPIO_MODE_OUT_PP);\
											GPIO_SetMode(LED_GREEN_PORT, LED_GREEN_PIN, GPIO_MODE_OUT_PP);\
										}while(0)
#define LED_Fini()						do{\
											GPIO_SetMode(LED_RED_PORT, LED_RED_PIN, GPIO_MODE_IN_FLOATING);\
											GPIO_SetMode(LED_GREEN_PORT, LED_GREEN_PIN, GPIO_MODE_IN_FLOATING);\
										}while(0)

// LED_RW
#define LED_RW_PORT						GPIOA
#define LED_RW_PIN						STM32VL_ST_LINK_LED
#define Led_RW_Init()					GPIO_SetMode(LED_RW_PORT, LED_RW_PIN, GPIO_MODE_OUT_PP)
#define Led_RW_ON()						GPIO_ClrPins(LED_RW_PORT, LED_RW_PIN)
#define Led_RW_OFF()					GPIO_SetPins(LED_RW_PORT, LED_RW_PIN)

// LED_USB
#define LED_USB_INIT()					
#define LED_USB_ON()					Led_RW_OFF()
#define LED_USB_OFF()					Led_RW_ON()

****************************** KEY ******************************
#define KEY_PORT						GPIOB
#define KEY_PIN							GPIO_PIN_9
#define KEY_IsDown()						//!GPIO_GetInPins(KEY_PORT, KEY_PIN)
#define KEY_Init()						//GPIO_SetMode(KEY_PORT, KEY_PIN, GPIO_MODE_IPU)
#define KEY_Fini()						//GPIO_SetMode(KEY_PORT, KEY_PIN, GPIO_MODE_IN_FLOATING)

*********************************  STM32VL Discovery  Definitions END  */

#define	STM32VL_ST_LINK_LED	GPIO_PIN_8	//GPIOA

#define LED_RED_PORT				GPIOA
//#define LED_RED_PIN				GPIO_PIN_15
#define LED_RED_PIN				STM32VL_ST_LINK_LED
#define LED_GREEN_PORT				GPIOA
#define LED_GREEN_PIN				GPIO_PIN_7	//GPIOA
#define LED_BLUE_PORT				GPIOA
#define LED_BLUE_PIN				GPIO_PIN_6	//GPIOA


#define LED_RED_ON()				GPIO_ClrPins(LED_RED_PORT, GPIO_PIN_GetMask(LED_RED_PIN))
#define LED_RED_OFF()				GPIO_SetPins(LED_RED_PORT, GPIO_PIN_GetMask(LED_RED_PIN))
#define LED_GREEN_ON()				GPIO_ClrPins(LED_GREEN_PORT, GPIO_PIN_GetMask(LED_GREEN_PIN))
#define LED_GREEN_OFF()				GPIO_SetPins(LED_GREEN_PORT, GPIO_PIN_GetMask(LED_GREEN_PIN))
#define LED_BLUE_ON()				GPIO_ClrPins(LED_BLUE_PORT, GPIO_PIN_GetMask(LED_BLUE_PIN))
#define LED_BLUE_OFF()				GPIO_SetPins(LED_BLUE_PORT, GPIO_PIN_GetMask(LED_BLUE_PIN))
#define LED_ALL_ON()				do{\
										LED_RED_ON();\
										LED_GREEN_ON();\
										LED_BLUE_ON();\
									}while(0)
#define LED_ALL_OFF()				do{\
										LED_RED_OFF();\
										LED_GREEN_OFF();\
										LED_BLUE_OFF();\
									}while(0)

#define LED_Init()					do{\
										GPIO_Dir(LED_RED_PORT, GPIO_MODE_Out_PP, LED_RED_PIN);\
										GPIO_Dir(LED_GREEN_PORT, GPIO_MODE_Out_PP, LED_GREEN_PIN);\
										GPIO_Dir(LED_BLUE_PORT, GPIO_MODE_Out_PP, LED_BLUE_PIN);\
									}while(0)

#define LED_Fini()					do{\
										GPIO_Dir(LED_RED_PORT, GPIO_MODE_IN_FLOATING, LED_RED_PIN);\
										GPIO_Dir(LED_GREEN_PORT, GPIO_MODE_IN_FLOATING, LED_GREEN_PIN);\
										GPIO_Dir(LED_BLUE_PORT, GPIO_MODE_IN_FLOATING, LED_BLUE_PIN);\
									}while(0)

/****************************** KEY ******************************/
#define ADC_PORT					GPIOB
#define ADC_PIN						GPIO_PIN_0

#define KEY_PORT					GPIOB
//#define KEY_PIN						GPIO_PIN_9
#define KEY_PIN						GPIO_PIN_1
#define KEY_IsDown()				(!GPIO_GetInPins(KEY_PORT, GPIO_PIN_GetMask(KEY_PIN)))
#define KEY_Init()					do{\
										GPIO_Dir(KEY_PORT, GPIO_MODE_IPU, KEY_PIN);\
									} while (0)
#define KEY_Fini()					do{\
										GPIO_Dir(KEY_PORT, GPIO_MODE_IN_FLOATING, KEY_PIN);\
									} while (0)

/****************************** USB *****************************/
// For USB 2.0, use DP
// For USB 1.1, use DM
#define USB_DP_PORT					GPIOA
#define USB_DP_PIN					GPIO_PIN_12

#define USB_Disable()				PowerOff()
#define USB_D_SETOUTPUT()			GPIO_Dir(USB_DP_PORT, GPIO_MODE_Out_PP, USB_DP_PIN)
#define USB_D_SET()					GPIO_SetPins(USB_DP_PORT, GPIO_PIN_GetMask(USB_DP_PIN))
#define USB_D_CLR()					GPIO_ClrPins(USB_DP_PORT, GPIO_PIN_GetMask(USB_DP_PIN))

/*************************** Includes ***************************/
#include "stm32f10x_lib.h"
//#include "myString.h"
#include "delay.h"
#include "HW.h"
